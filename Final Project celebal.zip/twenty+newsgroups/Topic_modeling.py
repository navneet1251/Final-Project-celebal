import os
import tarfile
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.cluster import KMeans
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
import nltk
import re
from sklearn.metrics import silhouette_score
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import joblib

# Download NLTK data files (only for the first time)
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

data_path = "C:\\Users\\NEHA1\\Downloads\\twenty+newsgroups\\20_newsgroups\\20_newsgroups"
extracted_path = "C:\\Users\\NEHA1\\Downloads\\twenty+newsgroups\\20_newsgroups\\20_newsgroups"

# Extract the archive if not already done
if not os.path.exists(extracted_path):
    with tarfile.open(data_path, 'r:gz') as tar:
        tar.extractall(path=os.path.dirname(data_path))
        print("Extraction completed.")

# Verify the extracted directories and files
for root, dirs, files in os.walk(extracted_path):
    print(f"Root: {root}")
    print(f"Directories: {dirs}")
    print(f"Files: {files}")
    print("-" * 50)

# Change the category to 'rec.sport.hockey'
category = 'talk.politics.misc'
category_path = os.path.join(extracted_path, category)

if not os.path.exists(category_path):
    raise FileNotFoundError(f"The category path does not exist: {category_path}")

documents = []

for file_name in os.listdir(category_path):
    file_path = os.path.join(category_path, file_name)
    with open(file_path, 'r', encoding='latin1') as file:
        documents.append(file.read())

# Preprocess the text data
stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()

def preprocess(text):
    # Remove non-alphabetic characters
    text = re.sub(r'[^a-zA-Z\s]', '', text, re.I|re.A)
    text = text.lower()
    text = text.strip()
    
    # Tokenize the text
    tokens = word_tokenize(text)
    
    # Remove stop words and lemmatize
    tokens = [lemmatizer.lemmatize(word) for word in tokens if word not in stop_words]
    return ' '.join(tokens)

documents = [preprocess(doc) for doc in documents]

# Convert the text data into numerical form using TF-IDF
vectorizer = TfidfVectorizer(max_df=0.9, min_df=2, stop_words='english')
X = vectorizer.fit_transform(documents)

# Function to display the topics found by LDA
def display_topics(model, feature_names, no_top_words):
    for topic_idx, topic in enumerate(model.components_):
        print(f"Topic {topic_idx}:")
        print(" ".join([feature_names[i] for i in topic.argsort()[:-no_top_words - 1:-1]]))

# Hyperparameter tuning for LDA
best_score = -1
best_n_topics = 0

for n_topics in range(5, 15):
    lda = LatentDirichletAllocation(n_components=n_topics, random_state=42)
    lda.fit(X)
    score = lda.bound_
    print(f"Number of Topics: {n_topics}, Log Likelihood Score: {score}")
    if score > best_score:
        best_score = score
        best_n_topics = n_topics

# Apply the best LDA model
lda = LatentDirichletAllocation(n_components=best_n_topics, random_state=42)
lda.fit(X)
display_topics(lda, vectorizer.get_feature_names_out(), 10)

# Save the LDA model
joblib.dump(lda, 'lda_model.joblib')

# Hyperparameter tuning for K-means
best_score = -1
best_n_clusters = 0

for n_clusters in range(5, 15):
    km = KMeans(n_clusters=n_clusters, random_state=42)
    km.fit(X)
    score = silhouette_score(X, km.labels_)
    print(f"Number of Clusters: {n_clusters}, Silhouette Score: {score}")
    if score > best_score:
        best_score = score
        best_n_clusters = n_clusters

# Apply the best K-means model
km = KMeans(n_clusters=best_n_clusters, random_state=42)
km.fit(X)
labels = km.labels_

# Save the K-means model
joblib.dump(km, 'kmeans_model.joblib')

# Attach the cluster labels to the documents
df = pd.DataFrame({'Document': documents, 'Cluster': labels})

# Display the clustering results
print(df.head())

# Save the clustering results to a CSV file
df.to_csv('document_clusters.csv', index=False)

# Visualize the top words in each topic using WordCloud
for topic_idx, topic in enumerate(lda.components_):
    wordcloud = WordCloud(background_color='white', width=800, height=400).generate(" ".join([vectorizer.get_feature_names_out()[i] for i in topic.argsort()[:-11 - 1:-1]]))
    plt.figure(figsize=(10, 5))
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis('off')
    plt.title(f'Topic {topic_idx}')
    plt.show()

# Visualize the document clusters
plt.figure(figsize=(10, 5))
plt.hist(labels, bins=best_n_clusters)
plt.title('Document Cluster Distribution')
plt.xlabel('Cluster')
plt.ylabel('Number of Documents')
plt.show()
